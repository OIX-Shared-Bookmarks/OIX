<?php
	header('Content-type: text/html; charset=utf-8');
	
	if(!isset($_GET['id']) || $_GET['id'] == "")
		$_GET['id'] = "boonbin";
                
	$logfile = "chatlogs/" . $_GET['id'] . ".txt";
	if(file_exists($logfile) == FALSE)
		file_put_contents($logfile, "<b><i>Welcome to " . $_GET['id'] . " chat</i></b>\n");
	
	if(isset($_POST['msg']))
	{
		$message = htmlspecialchars($_POST['msg']);
		
		if(strstr($message, ":") != false)
		{
			$message_pieces = explode(":", $message, 2);
			$_GET['prefix'] = $message_pieces[0];
		}
		else
		{
			unset($_GET['prefix']);
		}
	
		if($message != "" && $message != $_GET['prefix'] . ": " && $message != $_GET['prefix'] . ":")
		{
			if(isset($_GET['prefix']))
				$message = "<b>" . $message_pieces[0] . ":</b> " . str_replace("\'", "'", $message_pieces[1]);
			else
				$message = str_replace("\'", "'", $message);
			
			file_put_contents($logfile, '<b>' . date('[h:i:s] ', time()) . '</b> ' . $message . "\r\n", FILE_APPEND | LOCK_EX);
			
			if(isset($_GET['prefix']))
				header("Location: ?id=" . $_GET['id'] . "&prefix=" . $_GET['prefix']);
			else
				header("Location: ?id=" . $_GET['id']);
			exit;
		}
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
	<title><?php echo $_GET['id']; ?> chat</title>
</head> 
<body>
	<?php
		$lines = file($logfile, FILE_IGNORE_NEW_LINES);
		$lineslen = sizeof($lines);
		for($i = $lineslen-32; $i < $lineslen; $i++)
		{
			if(isset($lines[$i]))
			{
				if($i < $lineslen-24)
					echo $lines[$i] . "<br>";
				else
					echo $lines[$i] . "<br>";
			}
		}
	?>
	<form name="input" action="?id=<?php echo $_GET['id']; if(isset($_GET['prefix'])){echo "&prefix=" . $_GET['prefix'] . "";} ?>" method="post">
		<input type="text" size="50" <?php if(isset($_GET['prefix'])){echo "value=\"" . $_GET['prefix'] . ": \" ";} ?>placeholder="Enter your message here, don't forget to sign it with your name !" name="msg" autofocus="autofocus" onfocus="var temp_value=this.value; this.value=''; this.value=temp_value" class="form-control">
		<button type="submit" value="send / refresh" class="btn btn-default">&gt;</button>
	</form>
</body>
</html>

