<?php
    header('Content-type: text/html; charset=utf-8');
    date_default_timezone_set('UTC');
	
	if(!isset($_GET['id']) || $_GET['id'] == "")
        $_GET['id'] = "boonbin";

    if(!isset($_GET['lines']))
        $_GET['lines'] = 16;
        
    if(!is_dir('chatlogs'))
        mkdir('chatlogs');

	$logfile = "chatlogs/" . $_GET['id'] . ".txt";
	if(file_exists($logfile) == FALSE)
		file_put_contents($logfile, "<b><i>Welcome to " . $_GET['id'] . " chat</i></b>\n");
	
	if(isset($_POST['msg']))
	{
		$message = htmlspecialchars($_POST['msg']);
		
		if(strstr($message, ":") != false)
		{
			$message_pieces = explode(":", $message, 2);
			$_GET['prefix'] = $message_pieces[0];
		}
		else
		{
			unset($_GET['prefix']);
		}
	
		if($message != "" && $message != $_GET['prefix'] . ": " && $message != $_GET['prefix'] . ":")
		{
			if(isset($_GET['prefix']))
				$message = "<b>" . $message_pieces[0] . ":</b> " . str_replace("\'", "'", $message_pieces[1]);
			else
				$message = str_replace("\'", "'", $message);
			
			file_put_contents($logfile, '<font color="#333" title="' . date('d/m/y', time()) . '"><b>[</b>' . date('h:i:s', time()) . '<b>]</b></font> ' . $message . "\r\n", FILE_APPEND | LOCK_EX);
            exit;
		}
    }
?>
<!DOCTYPE html>
<html>
<head>
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
	<title><?php echo $_GET['id']; ?> chat</title>
    <style>
        *{margin:0;padding:0}body,html{width:100%;height:100%;overflow:hidden;background-color:#000;color:#336600}
        input
        {
            border-width: 0px;
            border-color: #000;
            background-color: #000;
            color: #fff;
            border-style: hidden;
            border-radius: 0px;
            width:100%;
        }
        input:focus
        {
            outline:none;
        }
        .fa
        {
            top: 0;
            left: 0;
            z-index: 2;
            position: absolute;
            width:100%;
        }
    </style>
</head> 
<body onclick="$('#msg').focus();">
<div id="content" onclick="$('#msg').focus();"></div>
<div id="mp" class="fa">
	<form autocomplete="off" id="msgform" name="input" action="?id=<?php echo $_GET['id']; if(isset($_GET['prefix'])){echo "&prefix=" . $_GET['prefix'] . "";} ?>" method="post">
		<input id="msg" type="text" <?php if(isset($_GET['prefix'])){echo "value=\"" . $_GET['prefix'] . ": \" ";} ?>placeholder="Enter your message here, don't forget to sign it with your name !" name="msg" autofocus="autofocus" class="form-control">
	</form>
</div>
<script>

    window.onresize = function()
    {
        $("#mp").css('top', (window.innerHeight-$("#msg").height()) +'px');
    }

    $(document).ready(function()
    {
        $("#content").load("content.php?id=<?php echo urlencode($_GET['id']); ?>&lines=<?php echo urlencode($_GET['lines']); ?>");
        $("#mp").css('top', (window.innerHeight-$("#msg").height()) + 'px');

        setInterval(function()
        {
            $("#content").load("content.php?id=<?php echo urlencode($_GET['id']); ?>&lines=<?php echo urlencode($_GET['lines']); ?>");
        }, 1000);

        $("#msgform").on("submit", function(e)
        {
            e.preventDefault();
            $.ajax(
            {
                type: "POST",
                url: "index.php?id=<?php echo urlencode($_GET['id']); ?>",
                data: $("#msgform").serialize(),
                success: function(data)
                {
                    $("#content").load("content.php?id=<?php echo urlencode($_GET['id']); ?>&lines=<?php echo urlencode($_GET['lines']); ?>");
                    var ts = $("#msg").val();
                    if(ts.indexOf(':') > -1)
                        $("#msg").val(ts.split(':')[0] + ": ");
                    else
                        $("#msg").val("");
                }
            });
        });
    });
</script>
</body>
</html>

