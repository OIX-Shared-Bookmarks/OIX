<?php
	header('Content-type: text/html; charset=utf-8');
	
	if(!isset($_GET['id']) || $_GET['id'] == "")
		$_GET['id'] = "boonbin";
                
	$logfile = "chatlogs/" . $_GET['id'] . ".txt";
	if(file_exists($logfile) == FALSE)
		file_put_contents($logfile, "<b><i>Welcome to " . $_GET['id'] . " chat</i></b>\n");
	
	if(isset($_POST['msg']))
	{
		$message = htmlspecialchars($_POST['msg']);
		
		if(strstr($message, ":") != false)
		{
			$message_pieces = explode(":", $message, 2);
			$_GET['prefix'] = $message_pieces[0];
		}
		else
		{
			unset($_GET['prefix']);
		}
	
		if($message != "" && $message != $_GET['prefix'] . ": " && $message != $_GET['prefix'] . ":")
		{
			if(isset($_GET['prefix']))
				$message = "<b>" . $message_pieces[0] . ":</b> " . str_replace("\'", "'", $message_pieces[1]);
			else
				$message = str_replace("\'", "'", $message);
			
			file_put_contents($logfile, '<b>' . date('[h:i:s] ', time()) . '</b> ' . $message . "\r\n", FILE_APPEND | LOCK_EX);
			
			if(isset($_GET['prefix']))
				header("Location: ?id=" . $_GET['id'] . "&prefix=" . $_GET['prefix']);
			else
				header("Location: ?id=" . $_GET['id']);
			exit;
		}
    }
?>
<!DOCTYPE html>
<html>
<head>
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
	<title><?php echo $_GET['id']; ?> - CHAT</title>
</head> 
<body>
<div id="content">
	<?php
		$lines = file($logfile, FILE_IGNORE_NEW_LINES);
		$lineslen = sizeof($lines);
		for($i = $lineslen-32; $i < $lineslen; $i++)
		{
			if(isset($lines[$i]))
			{
				if($i < $lineslen-24)
					echo $lines[$i] . "<br>";
				else
					echo $lines[$i] . "<br>";
			}
		}
	?>
</div>
	<form id="msgform" name="input" action="?id=<?php echo $_GET['id']; if(isset($_GET['prefix'])){echo "&prefix=" . $_GET['prefix'] . "";} ?>" method="post">
		<input id="msg" type="text" size="50" <?php if(isset($_GET['prefix'])){echo "value=\"" . $_GET['prefix'] . ": \" ";} ?>placeholder="Enter your message here, don't forget to sign it with your name !" name="msg" autofocus="autofocus" class="form-control">
		<button type="submit" value="send / refresh" class="btn btn-default">&gt;</button>
	</form>

<script>
	setInterval(function()
	{
		$("#content").load("content.php?id=<?php echo urlencode($_GET['id']); ?>");
	}, 1000);
	$("#msgform").on("submit", function(e)
	{
		e.preventDefault();
        $.ajax(
		{
            type: "POST",
            url: "index.php?id=<?php echo urlencode($_GET['id']); ?>",
            data: $("#msgform").serialize(),
            success: function(data)
			{
                $("#content").load("content.php?id=<?php echo urlencode($_GET['id']); ?>");
				var ts = $("#msg").val();
				if(ts.indexOf(':') > -1)
					$("#msg").val(ts.split(':')[0] + ": ");
				else
					$("#msg").val("");
            }
        });
    });
</script>
</body>
</html>

