<?php
	header('Content-type: text/html; charset=utf-8');
	
	if(!isset($_GET['id']) || $_GET['id'] == "")
		$_GET['id'] = "boonbin";
                
	$logfile = "chatlogs/" . $_GET['id'] . ".txt";

	$lines = file($logfile, FILE_IGNORE_NEW_LINES);
	$lineslen = sizeof($lines);
	for($i = $lineslen-16; $i < $lineslen; $i++)
	{
		if(isset($lines[$i]))
			echo $lines[$i] . "<br>";
	}
?>
