<?php
	header('Content-type: text/html; charset=utf-8');
	
	if(!isset($_GET['id']) || $_GET['id'] == "")
		$_GET['id'] = "boonbin";
                
	$logfile = "chatlogs/" . $_GET['id'] . ".txt";
	
	function getRealIpAddr()
	{
		if(!empty($_SERVER['HTTP_CLIENT_IP']))
		{
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
		{
			$i = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
	
	if(isset($_POST['msg']))
	{
		$message = htmlspecialchars($_POST['msg']);
		
		if(strstr($message, ": ") != false)
		{
			$message_pieces = explode(":", $message, 2);
			$_GET['prefix'] = $message_pieces[0];
		}
		else
		{
			unset($_GET['prefix']);
		}
	
		if($message != "" && $message != $_GET['prefix'] . ": ")
		{
			if(isset($_GET['prefix']))
				$message = "<b>" . $message_pieces[0] . ":</b> " . str_replace("\'", "'", $message_pieces[1]);
			else
				$message = str_replace("\'", "'", $message);
					
			$message = preg_replace("/\:\)/", "<img src=\"smiles/happy.gif\" alt=\":)\"></img>", $message);
			$message = preg_replace("/\;\)/", "<img src=\"smiles/wink.gif\" alt=\";)\"></img>", $message);
			$message = preg_replace("/\:\(/", "<img src=\"smiles/sad.png\" alt=\":(\"></img>", $message);
			$message = preg_replace("/\:\'\(/", "<img src=\"smiles/cry.png\" alt=\":'(\"></img>", $message);
			$message = preg_replace("/\¬\_\¬/", "<img src=\"smiles/doubt.gif\" alt=\"¬_¬\"></img>", $message);
			$message = preg_replace("/\:D/", "<img src=\"smiles/grin.gif\" alt=\":D\"></img>", $message);
			$message = preg_replace("/\:S/", "<img src=\"smiles/pout.png\" alt=\":S\"></img>", $message);
			$message = preg_replace("/\:\|/", "<img src=\"smiles/hmm.png\" alt=\":|\"></img>", $message);
					
			$xml = @simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".getRealIpAddr());
			$flagpath = "gif/" . strtolower($xml->geoplugin_countryCode) . ".gif";
			if(file_exists($flagpath) == false)
				$flagpath = "gif/bo.gif";
			file_put_contents($logfile, "<img src=\"$flagpath\" /> " . $message . "\r\n", FILE_APPEND | LOCK_EX);
			
			if(isset($_GET['prefix']))
				header("Location: ?id=" . $_GET['id'] . "&prefix=" . $_GET['prefix']);
			else
				header("Location: ?id=" . $_GET['id']);
			exit;
		}
    }
?>
<!DOCTYPE html>
<html>
<head>
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0" />
	<title><?php echo $_GET['id']; ?> - OIX CHAT</title>
	<style>
		@media(max-width: 370px){.mobile-content{display:none;}}
		::-webkit-scrollbar{width: 8px;height: 8px;}
		::-webkit-scrollbar-button{width: 0px;height: 0px;}
		::-webkit-scrollbar-thumb{background: #5bc0de;border: 0px none #ffffff;border-radius: 0px;}
		::-webkit-scrollbar-thumb:hover{background: #228aa8;}
		::-webkit-scrollbar-thumb:active{background: #228baa;}
		::-webkit-scrollbar-track{background: #fdfdfd;border: 0px none #ffffff;border-radius: 0px;}
		::-webkit-scrollbar-track:hover{background: #ffffff;}
		::-webkit-scrollbar-track:active{background: #fdfdfd;}
		::-webkit-scrollbar-corner{background: transparent;}
	</style>
</head> 
<body>
	<div class="container" style="min-width:320px;">
	<div class="col-xs-12">&nbsp;</div>
	<div class="col-xs-12">
		<form name="input" action="?id=<?php echo $_GET['id']; if(isset($_GET['prefix'])){echo "&prefix=" . $_GET['prefix'] . "";} ?>" method="post">
		<div class="input-group input-group-sm">
			<span class="mobile-content input-group-btn">
			<button class="btn btn-success"><b style="color:#fff;cursor:pointer;" class="glyphicon glyphicon-refresh"></b></button>
			</span>
		<input type="text" <?php if(isset($_GET['prefix'])){echo "value=\"" . $_GET['prefix'] . ": \" ";} ?>placeholder="Enter your message here, don't forget to sign it with your name !" name="msg" autofocus="autofocus" onfocus="var temp_value=this.value; this.value=''; this.value=temp_value" class="form-control">
			<span class="input-group-btn">
			<button type="submit" class="btn btn-default"><b>Go!</b></button>
			</span>
		</div>
		</form>
	</div>
	<div class="col-xs-12">&nbsp;</div>
	<div class="col-xs-12">
<ul class="list-group">	
<?php
	
	if(file_exists($logfile) == FALSE)
		file_put_contents($logfile, "<b><i>Welcome to https://github.com/OIX-Shared-Bookmarks chat</i></b>\n");
		
	$lines = file($logfile, FILE_IGNORE_NEW_LINES);
	
	$lineslen = sizeof($lines);
	for($i = $lineslen-1; $i > $lineslen-48; $i--)
	{
		if(isset($lines[$i]))
		{
			$url = "#";
			$newmsg = "";
			$addmsg = "";
			$lp = explode(" ", $lines[$i]);
			foreach($lp as $lpi)
			{
				if(strstr($lpi, "http://") != false || strstr($lpi, "https://") != false)
				{
					$url = $lpi;
					$addmsg = " <font color=blue><b>(Click Me)</b></font>";
				}
				else
				{
					$newmsg .= $lpi . " ";
				}
			}
			
			if($newmsg != "")
				$lines[$i] = $newmsg;
			
			if($i < $lineslen-24)
				echo "<a href=\"$url\" target=\"_blank\" class=\"hidden-xs list-group-item\">$lines[$i] $addmsg</a>";
			else
				echo "<a href=\"$url\" target=\"_blank\" class=\"list-group-item\">$lines[$i] $addmsg</a>";
		}
	}

?>
</ul>
</div>
</body>
</html>
